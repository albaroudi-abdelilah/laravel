<?php
require 'db.php';

$id = $_GET['id'];

$sql = "DELETE FROM budgets WHERE id=$id";

if (mysqli_query($conn, $sql)) {
    header("Location: index.php");
} else {
    echo "<!DOCTYPE html><html><body><p>Error: " . mysqli_error($conn) . "</p></body></html>";
}
?>