<?php
require 'db.php';
session_start();
$user_id = $_SESSION['user_id'];
$result = mysqli_query($conn, "SELECT * FROM budgets WHERE user_id = $user_id");
?>
<!DOCTYPE html>
<html>
<head><title>Budget List</title></head>
<body>
    <h2>Welcome, <?php echo $_SESSION['username']; ?>!</h2>
    <a href="logout.php">Logout</a>
    <h3>Budget List</h3>
    <table border="1">
        <tr><th>Name</th><th>Amount</th><th>Actions</th></tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['amount']; ?></td>
            <td>
                <a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a> | 
                <a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
    <h3>Add New Budget</h3>
    <form action="store.php" method="post">
        Name: <input type="text" name="name"><br><br>
        Amount: <input type="number" name="amount" step="0.01"><br><br>
        <button type="submit">Add Budget</button>
    </form>
</body>
</html>
