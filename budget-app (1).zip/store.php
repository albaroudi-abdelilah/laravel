<?php
require 'db.php';
session_start();

$name = $_POST['name'];
$amount = $_POST['amount'];
$user_id = $_SESSION['user_id'];

$sql = "INSERT INTO budgets (name, amount, user_id) VALUES ('$name', '$amount', $user_id)";

if (mysqli_query($conn, $sql)) {
    header("Location: index.php");
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
