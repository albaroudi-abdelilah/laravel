<?php
require 'db.php';

$id = $_POST['id'];
$name = $_POST['name'];
$amount = $_POST['amount'];

$sql = "UPDATE budgets SET name='$name', amount='$amount' WHERE id=$id";

if (mysqli_query($conn, $sql)) {
    header("Location: index.php");
} else {
    echo "<!DOCTYPE html><html><body><p>Error: " . mysqli_error($conn) . "</p></body></html>";
}
?>