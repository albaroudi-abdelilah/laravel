<?php
require 'db.php';

$id = $_GET['id'];
$result = mysqli_query($conn, "SELECT * FROM budgets WHERE id = $id");
$budget = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Budget</title>
</head>
<body>
    <h2>Edit Budget</h2>
    <form action="update.php" method="post">
        <input type="hidden" name="id" value="<?= $budget['id'] ?>">
        Name: <input type="text" name="name" value="<?= htmlspecialchars($budget['name']) ?>" required><br><br>
        Amount: <input type="number" step="0.01" name="amount" value="<?= $budget['amount'] ?>" required><br><br>
        <button type="submit">Update</button>
    </form>
    <br>
    <a href="index.php">Back</a>
</body>
</html>