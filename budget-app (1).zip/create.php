<!DOCTYPE html>
<html>
<head>
    <title>Add Budget</title>
</head>
<body>
    <h2>Add New Budget</h2>
    <form action="store.php" method="post">
        Name: <input type="text" name="name" required><br><br>
        Amount: <input type="number" step="0.01" name="amount" required><br><br>
        <button type="submit">Save</button>
    </form>
    <br>
    <a href="index.php">Back</a>
</body>
</html>